window.onload=function(){
    Plotly.d3.csv("datasetprova2.csv", function (error, data) {
        if (error) {
            return console.warn(error);
        }

        let perc1 = [], perc2 = [], perc3 = [], perc4 = [];
        let anno=[];
      data=data.filter( function(v){
          return  v.TIPO_DATO_AVQ=="14_FUMO_SI"
              &&  v.Sesso=="totale"
              && v.TIME==2018
              && v.MISURA_AVQ=="HSC"
            && v.TITOLO_STUDIO!=99
          && v.ETA1!="Y_GE14"
              ;}
      );
        /*Quattro vettori, uno per ciascun titolo di studio. Vengono ordinati per età*/
       let percent3=data.filter(function(v){return v.TITOLO_STUDIO==3;}).sort(function(a,b){return -b.ETA1+a.ETA1;});
       let percent4=data.filter(function(v){return v.TITOLO_STUDIO==4;}).sort(function(a,b){return -b.ETA1+a.ETA1;});
       let percent7=data.filter(function(v){return v.TITOLO_STUDIO==7;}).sort(function(a,b){return -b.ETA1+a.ETA1;});
       let percent11=data.filter(function(v){return v.TITOLO_STUDIO==11;}).sort(function(a,b){return -b.ETA1+a.ETA1;});

        document.body.appendChild(tableToHtmlElement(data));

        //salvo i valori delle percentuali che verranno assegnati alle tracce da rappresentare graficamente
        for (let i = 0; i < percent3.length; ++i)
            perc1[i]=percent3[i].Value;
        for (let i = 0; i < percent4.length; ++i)
            perc2[i]=percent4[i].Value;
        for (let i = 0; i < percent7.length; ++i)
            perc3[i]=percent7[i].Value;
        for (let i = 0; i < percent11.length; ++i)
            perc4[i]=percent11[i].Value;

        for (let i = 0; i < data.length; ++i) {
            anno.push(data[i]["Classe di eta"]);
        }
        let annoo=[];
        annoo=unique(anno);
        //Mi interessa la stampa della proprietà: Classe di età, devo ordinare in maniera crescente anche il vettore
        // da stampare sul grafico nelle ascisse, secondo questa proprietà per essere coerente con l'ordine assegnato ai
        // quattro vettori dei dati da rappresentare.
        annoo.sort(function(a,b){
            return -(+b.split(/[- ]/)[0]-a.split(/[- ]/)[0]);
        })

        console.log(annoo);
        let tracce = [
            {
                name: "Licenza di scuola Elementare",
                x: annoo,
                y: perc1,
                type: "scatter",
                line: {color:"purple", shape: "line"}
            },
            {
                name: "Licenza di scuola Media",
                x: annoo,
                y: perc2,
                type: "scatter"
            },
            {
                name: "Diploma",
                x: annoo,
                y: perc3,
                type: "scatter"
            },
            {
                name: "Laurea e post-laurea",
                x: annoo,
                y: perc4,
                type: "scatter",
                line: {color:"blue", shape: "line"}
            }];
        let layout = {
            title:{text:"Quanto il titolo di studio e l'età influenzano il vizio del fumo",

                font: {
                    size: 15,
                    color: '#DC143C'


                }
            },


            xaxis: {
                title: {
                    text: 'Età',
                    font: {
                        family: 'Courier New, monospace',
                        size: 18,
                        color: '#7f7f7f'
                    }
                },

            },
          yaxis: {
                title: {
                    text: 'Percentuale',
                    font: {
                        family: 'Courier New, monospace',
                        size: 18,
                        color: '#7f7f7f'
                    }
                },

                ticksuffix:"%",

                range:[0,35],
            },

        };

        console.log(layout);

        Plotly.plot("fumo4", tracce, layout);



    });
}

function unique(origArr) {
    //Funzione che elimina elementi duplicati in un vettore
    var newArr = [],
        origLen = origArr.length,
        found, x, y;

    for (x = 0; x < origLen; x++) {
        found = undefined;
        for (y = 0; y < newArr.length; y++) {
            if (origArr[x] === newArr[y]) {
                found = true;
                break;
            }
        }
        if (!found) {
            newArr.push(origArr[x]);
        }
    }
    return newArr;
}

function tableToHtmlElement(data){
    let res = document.createElement("table");
    let html ="<tr>";
    for(let h in data[0])
        if(data[0].hasOwnProperty(h))
            html+="<th>"+h+"</th>";
    html+="</tr>";
    for(let i=0; i<(data.length); ++i){
        html+="<tr>";
        for(let f in data[i])
            if(data[i].hasOwnProperty(f))
                html+="<td>"+data[i][f]+"</td>";
        html+="</tr>";
    }
    html+="</table>";
    res.innerHTML = html;
    return res;
}
