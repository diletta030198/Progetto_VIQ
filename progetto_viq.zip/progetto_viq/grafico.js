window.onload = function () {

    var url="datiGraficoEta.csv";
    Plotly.d3.csv(url, function(error,data) {
        if (error) return console.warn(error);

        data= data.filter (
            function(v){

                //filtro i dati, togliendo le righe in cui la colonna sesso= "totale"
                //prendendo solo le righe relative a "14_FUMO_SI"
                //prendendo solo le righe con delle misure effettuate su un campione di 100 persone (HSC)
                //togliendo le righe che riportano i dati relativi a tutte le età superiori ai 14 anni "Y_GE14"

                return v.Sesso!= "totale" &&
                    v.TIPO_DATO_AVQ== "14_FUMO_SI" &&
                    v.MISURA_AVQ==="HSC" && v.ETA1!="Y_GE14"


            }



        );
        document.body.appendChild(tableToHtmlElement(data));


        //definisco questa funzione per eliminare elementi ripetuti all'interno di un vettore
        function unique(origArr) {

            var newArr = [],

                origLen = origArr.length,

                found, x, y;



            for (x = 0; x < origLen; x++) {

                found = undefined;

                for (y = 0; y < newArr.length; y++) {

                    if (origArr[x] === newArr[y]) {

                        found = true;

                        break;

                    }

                }

                if (!found) {

                    newArr.push(origArr[x]);

                }

            }

            return newArr;

        }




        let eta =[];
        let maschi =[];
        let femmine =[];
        let eta2=[];



        for (let i=0; i< data.length; i++){
            let row = data[i];


            eta.push(row.ETA1);

            eta2.push(row["Classe di eta"]);

            if(row.Sesso==="femmine")
                femmine.push(row.Value);
            if(row.Sesso==="maschi")
                maschi.push(row.Value);
        }




        var eta1= unique(eta);
        var eta3= unique(eta2);


        eta3.sort(function(a,b){


            return +b.split(/[- ]/)[0]-a.split(/[- ]/)[0];
        })






        eta1.sort(function(a,b){


            var num1= (+a[1])*10+(+a[2]);
            var num2= (+b[1])*10+(+b[2]);
            return num1-num2;

        })



        let traces = [
            {
                name:"femmine",
                y:  eta3,
                x:femmine,
                orientation: "h",
                type :"bar",
                //aggiungi il text
                marker: {color: 'rgb(250, 128, 114)'}

            },

            {
                name:"maschi",
                y:eta3,
                x:maschi,
                orientation: "h",
                xaxis : "x2",
                type: "bar",
                marker : {color: 'rgb(100, 149, 237)'}

            }
        ];






        let layout = {

            title:{
                text:"Distribuzione (%) del campione abitudine al fumo. Analisi secondo età e il sesso",
                font :{
                    size:16,
                    color: '#DC143C'
                }

            },

            xaxis: {


                range :[35,0],
                title: {
                    text: 'Percentuale fumatrici',
                    font: {
                        family: 'Courier New, monospace',
                        size: 18

                    }, },


                domain: [0,0.40],

                ticksuffix:"%"



            },

            xaxis2:  {
                range :[0,35],

                title: {
                    text: 'Percentuale fumatori',
                    font: {
                        family: 'Courier New, monospace',
                        size: 18

                    },
                },
                domain: [0.55,1],

                ticksuffix:"%"
            },

            yaxis: {

                title: {

                    font: {
                        family: 'Courier New, monospace',
                        size: 18

                    },
                },
                position: 0.52
            },

            legend: {
                y:1.00, x:0.4,
                yanchor: "bottom",
                xarchor:"center",
                orientation:"v",
            }
        };


        Plotly.plot("fumo1",traces,layout); });








}

function tableToHtmlElement(data){
    let res = document.createElement("table");
    let html ="<tr>";
    for(let h in data[0])
        if(data[0].hasOwnProperty(h))
            html+="<th>"+h+"</th>";
    html+="</tr>";
    for(let i=0; i<data.length; ++i){
        html+="<tr>";
        for(let f in data[i])
            if(data[i].hasOwnProperty(f))
                html+="<td>"+data[i][f]+"</td>";
        html+="</tr>";
    }
    html+="</table>";
    res.innerHTML = html;
    return res;
}
