function disegna(eta, studio) {

    Plotly.d3.csv("datasetprova2.csv", function (error, data) {
        if (error) {
            console.error(error);
            document.getElementById("graphSigarette").innerHTML = "Cannot load data!";
            return;
        }


        let classiSigaretteX = []; // conterrà la classe che indica il numero di sigarette fumate giornalmente

        let numSigaretteY = []; // conterrà la percentuale di fumatori che fumano un certo numero di sigarette


    // si filtrano i dati tenendo conto dell'età e del titolo di studio inseriti in input. Si selezionano le righe
        // del file csv che contengono informazioni riguardo al numero di
    // sigarette fumate (v.TIPO_DATO_AVQ), senza distinzione di sesso, prendendo solo i valori in perccentuale
    // (v.MISURA_AVQ == "HSC") e nell'anno 2018

        data = data.filter(function (v) {
            return (v.TIPO_DATO_AVQ == "14_FUMO_SIGAR_11-20" || v.TIPO_DATO_AVQ == "14_FUMO_SIGAR_6-10" ||
                v.TIPO_DATO_AVQ == "14_FUMO_SIGAR_5" || v.TIPO_DATO_AVQ == "14_FUMO_SIGAR_GE20") && v.Sesso == "totale" && v.MISURA_AVQ == "HSC" && v.TIME == 2018
                && v.ETA1 == eta && v.TITOLO_STUDIO == studio
        });

        document.getElementById("tableData").innerHTML = "";
        document.getElementById("tableData").appendChild(tableToHtmlElement(data));


        for (let i = 0; i < data.length; ++i) { // si salvano i dati anteponendo un numero al fine di ordinarli per numero di sigarette crescenti
            let row = data[i];

            if (row["Tipo dato"] == "fino a 5 sigarette") {
                classiSigaretteX.push("1-" + row["Tipo dato"]);
                numSigaretteY.push("1-" + row.Value);
            }

            if (row["Tipo dato"] == "da 6 a 10 sigarette") {
                classiSigaretteX.push("2-" + row["Tipo dato"]);
                numSigaretteY.push("2-" + row.Value);
            }

            if (row["Tipo dato"] == "da 11 a 20 sigarette") {
                classiSigaretteX.push("3-" + row["Tipo dato"]);
                numSigaretteY.push("3-" + row.Value);
            }

            if (row["Tipo dato"] == "oltre 20 sigarette") {
                classiSigaretteX.push("4-" + row["Tipo dato"]);
                numSigaretteY.push("4-" + row.Value);
            }

        }

        var trace = {
            x: classiSigaretteX,
            y: numSigaretteY,
            type: "bar",
            orientation: "v",
            marker: {
                color: "orange",
            }
        };

        trace.x.sort(function (a, b) {
            return a.localeCompare(b);
        });

        trace.y.sort(function (a, b) {
            return a.localeCompare(b);
        });

        for (let i = 0; i < trace.x.length; i++) { // una volta ordinati i valori si rimuovono i numeri iniziali usati per l'ordinamento
            trace.x[i] = trace.x[i].split("-")[1];
        }
        for (let i = 0; i < trace.y.length; i++) {
            trace.y[i] = trace.y[i].split("-")[1];
        }

        var layout = {

            title: {
               text: "Consumo medio di sigarette al giorno nel 2018",
            font:{
                size:16,
                color:"#DC143C"
            },},
            xaxis: {
                title: {
                    text: "Numero di sigarette al giorno",
                    font: {
                        family: 'Courier New, monospace',
                        size: 18
                    }
                }

            },
            yaxis: {
                title: {
                    text: "Percentuale",
                    font: {
                        family: 'Courier New, monospace',
                        size: 18
                    }
                },
                ticksuffix: " %",
                range: [0, 40]
            },
            margin: {
                t: 50,
                l: 100, r: 50,
                b: 50
            }
        };
        Plotly.newPlot("fumo3", [trace], layout);
    });
}

window.onload = function () { //quando la finestra viene caricata viene disegnato il grafico
    let eta = document.getElementById("eta");
    let studio = document.getElementById("studio");
    disegna(eta.value, studio.value);

    eta.onchange = function () { //al cambiare dei parametri di input vengono disegnati nuovi grafici
        let eta = document.getElementById("eta").value;
        let studio = document.getElementById("studio").value;
        console.log(eta, studio);
        disegna(eta, studio);
    };
    studio.onchange = function () {
        let eta = document.getElementById("eta").value;
        let studio = document.getElementById("studio").value;
        console.log(eta, studio);
        disegna(eta, studio);
    };
}

function tableToHtmlElement(data){
    let res = document.createElement("table");
    let html ="<tr>";
    for(let h in data[0])
        if(data[0].hasOwnProperty(h))
            html+="<th>"+h+"</th>";
    html+="</tr>";
    for(let i=0; i<data.length; ++i){
        html+="<tr>";
        for(let f in data[i])
            if(data[i].hasOwnProperty(f))
                html+="<td>"+data[i][f]+"</td>";
        html+="</tr>";
    }
    html+="</table>";
    res.innerHTML = html;
    return res;
}
